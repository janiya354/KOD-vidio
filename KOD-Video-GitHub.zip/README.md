# KOD Video — GitHub Edition

This is a phone-friendly GitHub Pages/PWA starter for KOD Video.

## Deploy with GitHub Pages
1. Create a new GitHub repository.
2. Upload all files from this ZIP to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for the Pages URL.

## Important
This starter uses YouTube's public thumbnail URLs and the official YouTube embedded player for the demo videos. The sample video IDs are placeholders for development.

For real search/recommendations, connect an authorized YouTube Data API backend. Do NOT put a secret API key in browser JavaScript.

The UI intentionally uses original KOD branding rather than copying YouTube's proprietary branding/assets.

## Next build
- Authorized YouTube API backend
- Real search
- Sri Lankan music recommendation ranking
- User accounts
- Subscriptions/history
- Better player controls
- PWA install polish
- Optional Android wrapper/build workflow
