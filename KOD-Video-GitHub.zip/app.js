const videos=[
 {id:"dQw4w9WgXcQ",title:"Sri Lankan Music Mix — Demo",channel:"KOD Music",views:"120K",time:"2 days ago",cat:"Music"},
 {id:"M7lc1UVf-VE",title:"Sinhala Music & Live Session — Demo",channel:"KOD Music",views:"89K",time:"4 days ago",cat:"Music"},
 {id:"ysz5S6PUM-U",title:"Sri Lanka Gaming Highlights — Demo",channel:"KOD Gaming",views:"54K",time:"1 week ago",cat:"Gaming"},
 {id:"ScMzIvxBSi4",title:"Sinhala Chill Mix — Demo",channel:"KOD Music",views:"210K",time:"1 week ago",cat:"Music"}
];
const shorts=[
 {id:"M7lc1UVf-VE",title:"Sri Lankan Short — Demo"},
 {id:"ysz5S6PUM-U",title:"Gaming Short — Demo"},
 {id:"ScMzIvxBSi4",title:"Music Short — Demo"},
 {id:"dQw4w9WgXcQ",title:"Trending Short — Demo"}
];
let category="All";
const chips=["All","Music","Gaming","Mixes","Podcasts","Live","🇱🇰 Sri Lanka"];
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function thumb(id){return `https://i.ytimg.com/vi/${id}/hqdefault.jpg`}
function setCategory(c){category=c;render()}
function renderChips(){document.getElementById("chips").innerHTML=chips.map(c=>`<button class="chip ${category===c?'active':''}" onclick="setCategory('${c}')">${c}</button>`).join("")}
function card(v){return `<article class="card" onclick="openPlayer('${v.id}','${esc(v.title)}','${esc(v.channel)}')"><img class="thumb" src="${thumb(v.id)}" alt=""><div class="ctitle">${esc(v.title)}</div><div class="meta">${esc(v.channel)} · ${v.views} views · ${v.time}</div></article>`}
function render(){
 renderChips();
 const q=document.getElementById("search").value.toLowerCase();
 let list=videos.filter(v=>(category==="All"||category==="🇱🇰 Sri Lanka"||v.cat===category)&&(!q||v.title.toLowerCase().includes(q)||v.channel.toLowerCase().includes(q)));
 document.getElementById("musicGrid").innerHTML=list.length?list.map(card).join(""):`<div class="empty"><p>No matching videos.</p></div>`;
 document.getElementById("trendGrid").innerHTML=videos.slice().sort((a,b)=>parseInt(b.views)-parseInt(a.views)).map(card).join("");
 document.getElementById("shortsGrid").innerHTML=shorts.map(s=>`<article class="short" onclick="openPlayer('${s.id}','${esc(s.title)}','KOD Shorts')"><img src="${thumb(s.id)}" alt=""><p>${esc(s.title)}</p></article>`).join("");
}
function showTab(id){
 document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
 document.getElementById(id).classList.add("active");
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.tab===id));
 window.scrollTo(0,0);
}
function focusSearch(){showTab("home");document.getElementById("search").focus()}
function openPlayer(id,title,channel){
 document.getElementById("player").classList.add("show");
 document.getElementById("player").setAttribute("aria-hidden","false");
 document.getElementById("playerContent").innerHTML=`<iframe src="https://www.youtube.com/embed/${id}?rel=0" title="${title}" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
 document.getElementById("playerInfo").innerHTML=`<h2>${title}</h2><p>${channel}</p><div class="chips"><button class="chip">♡ Like</button><button class="chip">↗ Share</button><button class="chip">🔖 Save</button></div>`;
}
function closePlayer(){document.getElementById("player").classList.remove("show");document.getElementById("playerContent").innerHTML=""}
function openCreate(){document.getElementById("create").classList.add("show")}
function closeCreate(){document.getElementById("create").classList.remove("show")}
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
render();